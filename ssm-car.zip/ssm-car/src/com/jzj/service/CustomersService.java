package com.jzj.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.jzj.pojo.Customers;

import java.util.List;
import java.util.Map;

public interface CustomersService {
    //查找普通客户信息
    public List<Customers> findMore(Integer vip);

    //添加客户信息
    public void insertOne(Customers customers);

    //修改客户信息
    int changeOne(Customers customers);

    //删除用户
    int removeOne(int id);

    //echarts展示用户信息
    String showCustomers() throws JsonProcessingException;
}
