package com.jzj.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jzj.mapper.CustomersMapper;
import com.jzj.pojo.Customers;
import com.jzj.service.CustomersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

@Service
public class CustomersServiceImpl implements CustomersService {

    @Autowired
    private CustomersMapper  customersMapper;

    @Override
    public List<Customers> findMore(Integer vip) {
        return customersMapper.selectMore(vip);
    }

    @Override
    public void insertOne(Customers customers) {
        customersMapper.insertOne(customers);
    }

    @Override
    public int changeOne(Customers customers) {
        int i = customersMapper.updateOne(customers);
        return i;
    }

    @Override
    public int removeOne(int id) {
        return customersMapper.deleteOne(id);
    }

    @Override
    public String showCustomers() throws JsonProcessingException {
        List<Customers> customers = customersMapper.selectData();
        LinkedHashSet<Object> cus = new LinkedHashSet<>();
        LinkedHashSet<String> addArr = new LinkedHashSet<>();
        ArrayList<Integer> numArr = new ArrayList<>();

        //取出来地名
        for (Customers customer : customers) {
            String address = customer.getAddress();
            addArr.add(address);
        }
        //取出来数量
        for (Customers customer : customers) {
            int num = customer.getNum();
            numArr.add(num);
        }
        cus.add(addArr);
        cus.add(numArr);
        //String jsonArr = cus.toString();不可行
        String jsonArr = new ObjectMapper().writeValueAsString(cus);

        return jsonArr;
    }

}
