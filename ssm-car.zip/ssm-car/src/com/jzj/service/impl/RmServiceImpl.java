package com.jzj.service.impl;

import com.jzj.mapper.RmMapper;
import com.jzj.service.RmService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RmServiceImpl implements RmService {

    @Autowired
    RmMapper rmMapper;

    @Override
    public List<Integer> findMid(int rid) {
        return rmMapper.selectMid(rid);
    }
}
