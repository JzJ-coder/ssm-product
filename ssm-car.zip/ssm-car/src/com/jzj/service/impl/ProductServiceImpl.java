package com.jzj.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jzj.mapper.ProductMapper;
import com.jzj.pojo.Product;
import com.jzj.pojo.Page;
import com.jzj.service.ProductService;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    ProductMapper productMapper;

    @Override
    public Page<Product> findAll(int page, int rows) {

        //进行分页设置
        com.github.pagehelper.Page page1 = PageHelper.startPage(page, rows);
        //获取总条数
        long total = page1.getTotal();
        List<Product> list = productMapper.selectAll();
        Page<Product> pg = new Page<>(list,total);
        return pg;
    }

    @Override
    public int addProduct(Product product) {
        return productMapper.addProduct(product);
    }

    @Override
    public int changeProduct(Product product) {
        return productMapper.update(product);
    }

    @Override
    public int removeOne(int id) {
        return productMapper.delete(id);
    }


    @Override
    public String showProduct() throws JsonProcessingException {
        List<Product> list = productMapper.selectData();

        ArrayList<Object> jsonArr = new ArrayList<>();

        ArrayList<String> nameArr = new ArrayList<>();
        ArrayList<Integer> numArr = new ArrayList<>();
        for (Product product : list) {
            String name = product.getName();
            nameArr.add(name);
        }
        for (Product product : list) {
            Integer number = product.getNumber();
            numArr.add(number);
        }
        jsonArr.add(nameArr);
        jsonArr.add(numArr);
        String s = new ObjectMapper().writeValueAsString(jsonArr);
        return s;
    }

}
