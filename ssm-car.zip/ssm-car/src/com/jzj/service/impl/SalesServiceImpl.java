package com.jzj.service.impl;

import com.jzj.mapper.SalesMapper;
import com.jzj.pojo.Sales;
import com.jzj.service.SalesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SalesServiceImpl implements SalesService {
    //注入mapper对象
    @Autowired
    private SalesMapper offlineSalesMapper;


    @Override
    public List<Sales> findOnline(Sales sales) {
        return offlineSalesMapper.selectOnline(sales);
    }

    @Override
    public List<Sales> findMore(Sales sales) {
        return offlineSalesMapper.selectMore(sales);
    }
}
