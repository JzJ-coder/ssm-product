package com.jzj.service.impl;

import com.jzj.mapper.SysUserMapper;
import com.jzj.pojo.Page;
import com.jzj.pojo.SysUser;
import com.jzj.service.SysUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SysUserServiceImpl implements SysUserService {

    @Autowired
    SysUserMapper sysUserMapper;

    @Override
    public Page<SysUser> findAll() {
        List<SysUser> list = sysUserMapper.selectAll();
        Page<SysUser> pg = new Page<>();
        pg.setRows(list);
        return pg;
    }

    @Override
    public SysUser login(String loginname, String pwd) {
        return sysUserMapper.selectUser(loginname, pwd);
    }
}
