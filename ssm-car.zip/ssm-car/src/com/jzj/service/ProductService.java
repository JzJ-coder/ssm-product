package com.jzj.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.jzj.pojo.Product;
import com.jzj.pojo.Page;

import java.util.List;


public interface ProductService {
    //查询所有产品信息
    public Page<Product> findAll(int page, int rows);
    //添加产品信息
    public int addProduct(Product product);
    //更改产品信息
    public int changeProduct(Product product);
    //删除一条信息
    public int removeOne(int id);
    //查询统计产品数量
    String showProduct() throws JsonProcessingException;
}
