package com.jzj.service;

import com.jzj.pojo.Page;
import com.jzj.pojo.SysUser;


public interface SysUserService {
    public Page<SysUser> findAll();
    //登录操作
    public SysUser login(String loginname,String pwd);
}
