package com.jzj.service;

import com.jzj.pojo.Sales;

import java.util.List;

public interface SalesService {
    //查询线上销售情况
    List<Sales> findOnline(Sales sales);

    //查询线下销售情况
    List<Sales> findMore(Sales sales);
}
