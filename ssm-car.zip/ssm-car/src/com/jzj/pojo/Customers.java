package com.jzj.pojo;

/***
 * 客户信息
 * @author Administrator
 *
 */
public class Customers {

	private Integer id;
	private String custname;
	private String address;
	private String phone;
	private int vip; // 0：普通客户 1：大客户
	//统计地区数量
	private int num;

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCustname() {
		return custname;
	}

	public void setCustname(String custname) {
		this.custname = custname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getVip() {
		return vip;
	}

	public void setVip(int vip) {
		this.vip = vip;
	}

	@Override
	public String toString() {
		return "Customers{" +
				"id=" + id +
				", custname='" + custname + '\'' +
				", address='" + address + '\'' +
				", phone='" + phone + '\'' +
				", vip=" + vip +
				'}';
	}
}
