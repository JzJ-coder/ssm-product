package com.jzj.pojo;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

public class Sales implements Serializable {
    private Integer id;
    private String name;
    private Integer count;
    private Double money;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date sdate;
    private String saler;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Double getMoney() {
        return money;
    }

    public void setMoney(Double money) {
        this.money = money;
    }

    @JsonFormat(pattern="yyyy-MM-dd",timezone="GMT+8")
    public Date getSdate() {
        return sdate;
    }

    public void setSdate(Date sdate) {
        this.sdate = sdate;
    }

    public String getSaler() {
        return saler;
    }

    public void setSaler(String saler) {
        this.saler = saler;
    }

    @Override
    public String toString() {
        return "Sales{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", count=" + count +
                ", money=" + money +
                ", sdate=" + sdate +
                ", saler='" + saler + '\'' +
                '}';
    }
}
