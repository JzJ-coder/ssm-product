package com.jzj.pojo;

/**
 * 产品信息
 */
public class Product {
    private Integer id;
    private String name; //产品名字
    private Double price; //产品价格
    private Integer number; //产品数量
    private String pdesc; //产品介绍
    private String img; //产品图片

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public String getPdesc() {
        return pdesc;
    }

    public void setPdesc(String pdesc) {
        this.pdesc = pdesc;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public Product(){

    }

    public Product(Integer id, String name, Double price, Integer number, String pdesc, String img) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.number = number;
        this.pdesc = pdesc;
        this.img = img;
    }
}
