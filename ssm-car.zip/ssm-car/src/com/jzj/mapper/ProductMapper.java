package com.jzj.mapper;

import com.jzj.pojo.Product;

import java.util.List;

public interface ProductMapper {

    //使用pageHelper结合mybatis分页查询
    public List<Product> selectAll();

    //添加产品信息
    public int addProduct(Product product);

    //修改信息
    public int update(Product product);

    //删除一条信息
    public int delete(int id);

    //统计产品数量
    List<Product> selectData();
}
