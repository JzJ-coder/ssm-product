package com.jzj.mapper;

import com.jzj.pojo.Customers;

import java.util.List;

public interface CustomersMapper {
    //查找客户
    public List<Customers> selectMore(Integer vip);
    //添加客户
    public int insertOne(Customers customers);
    //修改客户信息
    int updateOne(Customers customers);
    //删除用户
    public int deleteOne(int id);
    //echarts展示用户信息
    List<Customers> selectData();
}
