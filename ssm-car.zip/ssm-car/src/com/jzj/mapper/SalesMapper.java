package com.jzj.mapper;

import com.jzj.pojo.Sales;

import java.util.List;

public interface SalesMapper {
    //多条件查询线上销售情况
    public List<Sales> selectOnline(Sales sales);

    //多条件查询线下销售情况
    public List<Sales> selectMore(Sales sales);
}
