package com.jzj.mapper;

import com.jzj.pojo.SysUser;

import java.util.List;

public interface SysUserMapper {
    public List<SysUser> selectAll();

    //登录页面
    public SysUser selectUser(String loginname,String pwd);
}
