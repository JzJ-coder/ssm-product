package com.jzj.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jzj.pojo.Customers;
import com.jzj.service.CustomersService;
import org.omg.CORBA.INTERNAL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import java.util.*;

@Controller
@RequestMapping("CustomersController")
public class CustomersController {

    @Autowired
    CustomersService customersService;

    @RequestMapping("findMore")
    @ResponseBody
    public List<Customers> findMore(Integer vip){
        return customersService.findMore(vip);
    }

    @RequestMapping("addOne")
    @ResponseBody
    public int addOne(Customers customers){
        customersService.insertOne(customers);
        return 1;
    }

    @RequestMapping("changeOne")
    @ResponseBody
    public int changeOne(Customers customers){
        System.out.println(customers);
        return customersService.changeOne(customers);
    }

    @RequestMapping("removeOne")
    @ResponseBody
    public int removeOne(int id){
        return customersService.removeOne(id);
    }

    @RequestMapping("showCustomers")
    @ResponseBody
    public Map showCustomers(HttpServletResponse resp) throws JsonProcessingException {
        String s = customersService.showCustomers();
        resp.setContentType("application/json;charset=utf-8");
        Map<Object, Object> map = new HashMap<>();
        map.put("dataArr",s);
        return map;
    }
}
