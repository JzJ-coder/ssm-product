package com.jzj.controller;

import com.jzj.pojo.Sales;
import com.jzj.service.SalesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
@RequestMapping("SalesController")
public class SalesController {

    @Autowired
    private SalesService salesService;

    //查询线上销售情况
    @RequestMapping("findOnline")
    @ResponseBody
    public List<Sales> findOnline(Sales sales,HttpServletResponse resp){
        resp.setContentType("application/json;charset=utf-8");
        return salesService.findOnline(sales);
    }

    //查询线下销售情况
    @RequestMapping("findOffline")
    @ResponseBody
    public List<Sales> findOffline(Sales sales,HttpServletResponse resp){
        resp.setContentType("application/json;charset=utf-8");
        return salesService.findMore(sales);
    }
}
