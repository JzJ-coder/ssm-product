package com.jzj.controller;

import com.jzj.pojo.Product;
import com.jzj.pojo.Page;
import com.jzj.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.util.*;

@Controller
@RequestMapping("ProductController")
public class ProductController  {

    @Autowired
    ProductService productService;

    @RequestMapping("findAll")
    @ResponseBody
    public Page<Product> findAll(int page,int rows){
        Page<Product> list = productService.findAll(page, rows);
        return list;
    }

    @RequestMapping("addProduct")
    @ResponseBody
    public int addCars(Product product){
        return productService.addProduct(product);
    }

    //文件上传
    @RequestMapping("fileUpload")
    @ResponseBody
    public Map<String,String> fileUpload(HttpServletRequest req,MultipartFile fil){

        Map<String,String> map = new HashMap<>();
        try {
            //获取服务器地址
            String realPath = req.getServletContext().getRealPath("/img");

            File file = new File(realPath);
            //判断文件是否存在,不存在新建一个
            if(!file.exists()){
                file.mkdirs();
            }

            //获取文件名
            String substring = fil.getOriginalFilename().substring(fil.getOriginalFilename().lastIndexOf("."));
            String uuid = UUID.randomUUID().toString();
            String filename = uuid+substring;

            fil.transferTo(new File(realPath,filename));

            map.put("success",filename);
        } catch (IOException e) {
            e.printStackTrace();
            map.put("error","上传失败！");
        }
            return map;
    }

    //更改产品信息
    @RequestMapping("changeProduct")
    @ResponseBody
    public int changeProduct(Product product){
        return productService.changeProduct(product);
    }

    //删除一条信息
    @RequestMapping("removeOne")
    @ResponseBody
    public int removeOne(Integer id){
        return productService.removeOne(id);
    }
     private HttpServletRequest request;
     private HttpServletResponse response;
    @ModelAttribute
    public void init(HttpServletRequest request, HttpServletResponse response){
       this.request= (HttpServletRequest)request;
        this.response=(HttpServletResponse)response;
    }

    //查询产品统计信息
     @ResponseBody
     @RequestMapping("showNumber")
    public Map showNumber(HttpServletRequest req,HttpServletResponse resp) throws Exception {
        //[['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],[120, 200, 150, 80, 70, 110, 130]]
        //String s = "[['气动元件', '三通球阀', '4分内牙铜网通', '水暖器件', '过滤器', '内螺纹铜管帽', 'Fred'],[90, 200, 150, 80, 70, 110, 130]]";
        req.setCharacterEncoding("utf-8");
//        resp.setContentType("text/html;charset=utf-8");
        /*List<Product> list = productService.showProduct();
        LinkedHashSet<Set> set = new LinkedHashSet<>();
        LinkedHashSet<String> nameSet = new LinkedHashSet<>();
        LinkedHashSet<Integer> numberSet = new LinkedHashSet<>();
        for (Product product : list) {
            String name = product.getName();
            nameSet.add(name);
        }
        for (Product product : list) {
            Integer number = product.getNumber();
            numberSet.add(number);
        }
        set.add(nameSet);
        set.add(numberSet);
        String json = new ObjectMapper().writeValueAsString(set);
        json = json.replaceAll("\"", "\'");
         String s = json.toString();
         s.replaceAll("\"","'");
         HashMap map = new HashMap();
         map.put("s",s);
         return map;*/
         String s = productService.showProduct();
         HashMap<Object, Object> map = new HashMap<>();
         map.put("dataArr",s);
         return map;
     }

}
